//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WiRE3SoftwareTriggerDemo.rc
//
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_OUT_STATUS_STATIC           1000
#define IDC_OUT_COUNT_STATIC            1001
#define IDC_IN_STATUS_STATIC2           1002
#define IDC_RUN_SCAN_BUTTON             1003
#define IDC_NUM_TO_RUN_BTN              1004
#define IDC_AUTO_RUN_BTN                1005
#define IDC_BUTTON2                     1006
#define IDC_ABORT_BTN                   1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
