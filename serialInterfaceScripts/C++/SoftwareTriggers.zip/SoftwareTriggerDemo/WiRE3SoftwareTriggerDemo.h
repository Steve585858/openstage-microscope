// WiRE3SoftwareTriggerDemo.h
